<?php $__env->startSection('title', 'المصروفات'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ open: false, form: { id: null, expense_category_id: '', amount: '', description: '', payment_method: 'cash', spent_at: '<?php echo e(now()->toDateString()); ?>' } }">
    <div class="flex justify-between items-center mb-4 flex-wrap gap-3">
        <h2 class="text-lg font-bold text-slate-700">المصروفات</h2>
        <div class="flex gap-2">
            <a href="<?php echo e(route('accounting.expense-categories.index')); ?>" class="px-4 py-2 bg-slate-100 rounded-xl font-semibold">فئات المصروفات</a>
            <button @click="form = { id: null, expense_category_id: '', amount: '', description: '', payment_method: 'cash', spent_at: '<?php echo e(now()->toDateString()); ?>' }; open = true" class="bg-brand-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> مصروف جديد
            </button>
        </div>
    </div>

    <form method="GET" class="card p-4 flex flex-wrap gap-3 mb-4 items-end">
        <select name="category" class="px-3 py-2 rounded-xl border border-slate-200">
            <option value="">كل الفئات</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('category')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="px-3 py-2 rounded-xl border border-slate-200">
        <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="px-3 py-2 rounded-xl border border-slate-200">
        <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">تصفية</button>
        <span class="ms-auto text-sm font-bold text-slate-600">الإجمالي: <?php echo e(money($total)); ?></span>
    </form>

    <div class="card p-5 overflow-x-auto scrollbar-thin">
        <table class="w-full text-sm">
            <thead class="text-slate-400 text-right border-b"><tr><th class="py-2">الوصف</th><th class="py-2">الفئة</th><th class="py-2">المبلغ</th><th class="py-2">الدفع</th><th class="py-2">التاريخ</th><th class="py-2"></th></tr></thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="py-3 font-semibold text-slate-700"><?php echo e($e->description); ?></td>
                        <td class="py-3 text-slate-500"><?php echo e($e->category?->name); ?></td>
                        <td class="py-3 font-bold text-melon-600"><?php echo e(money($e->amount)); ?></td>
                        <td class="py-3 text-slate-500"><?php echo e(['cash'=>'نقدي','card'=>'بطاقة','transfer'=>'تحويل'][$e->payment_method] ?? $e->payment_method); ?></td>
                        <td class="py-3 text-slate-400"><?php echo e($e->spent_at->format('Y-m-d')); ?></td>
                        <td class="py-3">
                            <form method="POST" action="<?php echo e(route('accounting.expenses.destroy', $e)); ?>" onsubmit="return confirm('حذف المصروف؟')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="p-2 text-slate-400 hover:text-red-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="py-10 text-center text-slate-400">لا توجد مصروفات</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($expenses->links()); ?></div>

    <div x-show="open" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" @click.self="open=false">
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 class="font-bold text-lg mb-4">مصروف جديد</h3>
            <form method="POST" action="<?php echo e(route('accounting.expenses.store')); ?>" enctype="multipart/form-data" class="space-y-3">
                <?php echo csrf_field(); ?>
                <select name="expense_category_id" x-model="form.expense_category_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                    <option value="">اختر الفئة</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input name="description" x-model="form.description" placeholder="وصف المصروف" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                <div class="grid grid-cols-2 gap-3">
                    <input type="number" step="0.01" name="amount" x-model="form.amount" placeholder="المبلغ" required class="px-3 py-2 rounded-xl border border-slate-200">
                    <select name="payment_method" x-model="form.payment_method" class="px-3 py-2 rounded-xl border border-slate-200">
                        <option value="cash">نقدي</option><option value="card">بطاقة</option><option value="transfer">تحويل</option>
                    </select>
                </div>
                <input type="date" name="spent_at" x-model="form.spent_at" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                <input type="file" name="attachment" class="w-full text-sm">
                <div class="flex gap-2 pt-2">
                    <button class="flex-1 bg-brand-600 text-white py-2.5 rounded-xl font-bold">حفظ</button>
                    <button type="button" @click="open=false" class="px-4 bg-slate-100 rounded-xl">إلغاء</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/accounting/expenses/index.blade.php ENDPATH**/ ?>