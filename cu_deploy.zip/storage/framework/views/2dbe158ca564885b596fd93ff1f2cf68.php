<?php $__env->startSection('title', 'الأدوار والصلاحيات'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-6">
            <form method="POST" action="<?php echo e(route('admin.roles.update', $role)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-bold text-slate-700"><?php echo e($role->name); ?></h3>
                        <span class="text-xs text-slate-400"><?php echo e($role->users_count); ?> مستخدم · <?php echo e($role->permissions->count()); ?> صلاحية</span>
                    </div>
                    <?php if($role->name !== 'مدير'): ?>
                        <button class="bg-brand-600 text-white px-4 py-2 rounded-xl text-sm font-semibold">حفظ</button>
                    <?php else: ?>
                        <span class="text-xs text-slate-400">المدير يملك جميع الصلاحيات</span>
                    <?php endif; ?>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2 text-sm px-3 py-2 rounded-xl bg-slate-50 <?php echo e($role->name === 'مدير' ? 'opacity-60' : ''); ?>">
                            <input type="checkbox" name="permissions[]" value="<?php echo e($perm->name); ?>"
                                   <?php if($role->hasPermissionTo($perm->name)): echo 'checked'; endif; ?> <?php if($role->name === 'مدير'): echo 'disabled'; endif; ?>
                                   class="rounded text-brand-600">
                            <?php echo e($labels[$perm->name] ?? $perm->name); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>