<?php $__env->startSection('title', 'المكوّنات'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-4">
    <h2 class="text-lg font-bold text-slate-700">مكوّنات المخزون</h2>
    <a href="<?php echo e(route('inventory.ingredients.create')); ?>" class="bg-brand-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> مكوّن جديد
    </a>
</div>

<div class="card p-5">
    <form method="GET" class="flex flex-wrap gap-3 mb-4">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="بحث"
               class="flex-1 min-w-48 px-3 py-2 rounded-xl border border-slate-200 outline-none focus:border-brand-500">
        <select name="filter" class="px-3 py-2 rounded-xl border border-slate-200">
            <option value="">الكل</option>
            <option value="low" <?php if(request('filter')==='low'): echo 'selected'; endif; ?>>منخفض المخزون فقط</option>
        </select>
        <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">تصفية</button>
    </form>

    <div class="overflow-x-auto scrollbar-thin">
        <table class="w-full text-sm">
            <thead class="text-slate-400 text-right border-b">
                <tr>
                    <th class="py-2 font-medium">المكوّن</th>
                    <th class="py-2 font-medium">الوحدة</th>
                    <th class="py-2 font-medium">المخزون الحالي</th>
                    <th class="py-2 font-medium">حد التنبيه</th>
                    <th class="py-2 font-medium">تكلفة الوحدة</th>
                    <th class="py-2 font-medium">قيمة المخزون</th>
                    <th class="py-2 font-medium"></th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 <?php echo e($ing->isLowStock() ? 'bg-red-50/50' : ''); ?>">
                        <td class="py-3 font-semibold text-slate-700">
                            <?php echo e($ing->name); ?>

                            <?php if($ing->isLowStock()): ?><span class="text-xs text-red-600 mr-1">⚠️ منخفض</span><?php endif; ?>
                        </td>
                        <td class="py-3 text-slate-500"><?php echo e($ing->unit?->name); ?></td>
                        <td class="py-3 font-bold <?php echo e($ing->isLowStock() ? 'text-red-600' : ''); ?>"><?php echo e(number_format($ing->current_stock, 3)); ?></td>
                        <td class="py-3 text-slate-500"><?php echo e(number_format($ing->reorder_level, 3)); ?></td>
                        <td class="py-3"><?php echo e(money($ing->cost_per_unit)); ?></td>
                        <td class="py-3 font-semibold"><?php echo e(money($ing->current_stock * $ing->cost_per_unit)); ?></td>
                        <td class="py-3">
                            <div class="flex gap-1">
                                <a href="<?php echo e(route('inventory.ingredients.edit', $ing)); ?>" class="p-2 text-slate-400 hover:text-brand-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'edit','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a>
                                <form method="POST" action="<?php echo e(route('inventory.ingredients.destroy', $ing)); ?>" onsubmit="return confirm('حذف المكوّن؟')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="p-2 text-slate-400 hover:text-red-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="py-10 text-center text-slate-400">لا توجد مكوّنات</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($ingredients->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/inventory/ingredients/index.blade.php ENDPATH**/ ?>