<?php $__env->startSection('title', 'سجل الحركات المالية'); ?>

<?php $__env->startSection('content'); ?>
<form method="GET" class="card p-4 flex flex-wrap gap-3 mb-4 items-end">
    <select name="type" class="px-3 py-2 rounded-xl border border-slate-200">
        <option value="">كل الأنواع</option>
        <option value="income" <?php if(request('type')==='income'): echo 'selected'; endif; ?>>دخل</option>
        <option value="expense" <?php if(request('type')==='expense'): echo 'selected'; endif; ?>>مصروف</option>
    </select>
    <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="px-3 py-2 rounded-xl border border-slate-200">
    <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="px-3 py-2 rounded-xl border border-slate-200">
    <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">تصفية</button>
</form>

<div class="card p-5 overflow-x-auto scrollbar-thin">
    <table class="w-full text-sm">
        <thead class="text-slate-400 text-right border-b"><tr><th class="py-2">النوع</th><th class="py-2">الفئة</th><th class="py-2">الوصف</th><th class="py-2">المبلغ</th><th class="py-2">التاريخ</th></tr></thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3"><span class="px-2 py-0.5 rounded-full text-xs <?php echo e($t->type==='income' ? 'bg-brand-100 text-brand-700' : 'bg-melon-100 text-melon-600'); ?>"><?php echo e($t->type==='income' ? 'دخل' : 'مصروف'); ?></span></td>
                    <td class="py-3 text-slate-500"><?php echo e(str_replace('expense:', '', $t->category)); ?></td>
                    <td class="py-3 text-slate-700"><?php echo e($t->description); ?></td>
                    <td class="py-3 font-bold <?php echo e($t->type==='income' ? 'text-brand-600' : 'text-melon-600'); ?>"><?php echo e($t->type==='income' ? '+' : '-'); ?> <?php echo e(money($t->amount)); ?></td>
                    <td class="py-3 text-slate-400"><?php echo e($t->occurred_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="py-10 text-center text-slate-400">لا توجد حركات</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($transactions->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/accounting/transactions.blade.php ENDPATH**/ ?>