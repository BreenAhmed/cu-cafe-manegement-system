<?php
    $unread = auth()->user()->unreadNotifications()->take(8)->get();
    $activeShift = auth()->user()->activeShift()->first();
?>

<header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-20">
    <div class="flex items-center gap-3">
        <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-lg hover:bg-slate-100">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'list','class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'list','class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        </button>
        <h1 class="text-lg font-bold text-slate-800"><?php echo $__env->yieldContent('title', 'لوحة التحكم'); ?></h1>
    </div>

    <div class="flex items-center gap-2 sm:gap-4">
        <?php if($activeShift): ?>
            <span class="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 bg-brand-50 px-3 py-1.5 rounded-full">
                <span class="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
                وردية مفتوحة
            </span>
        <?php endif; ?>

        
        <div x-data="{ open: false }" class="relative">
            <button @click="open = !open" class="relative p-2 rounded-lg hover:bg-slate-100">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'bell','class' => 'w-6 h-6 text-slate-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bell','class' => 'w-6 h-6 text-slate-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <?php if($unread->count()): ?>
                    <span class="absolute top-1 left-1 w-4 h-4 text-[10px] flex items-center justify-center bg-melon-500 text-white rounded-full"><?php echo e($unread->count()); ?></span>
                <?php endif; ?>
            </button>
            <div x-show="open" x-cloak @click.outside="open = false"
                 class="absolute left-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden z-50">
                <div class="flex items-center justify-between px-4 py-3 border-b">
                    <span class="font-bold text-sm">الإشعارات</span>
                    <?php if($unread->count()): ?>
                        <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="text-xs text-brand-600 hover:underline">تعليم الكل كمقروء</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div class="max-h-80 overflow-y-auto scrollbar-thin divide-y">
                    <?php $__empty_1 = true; $__currentLoopData = $unread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e($note->data['url'] ?? route('notifications.index')); ?>"
                           class="flex gap-3 px-4 py-3 hover:bg-slate-50">
                            <span class="mt-0.5 w-2 h-2 rounded-full shrink-0
                                <?php echo e(['info'=>'bg-blue-500','warning'=>'bg-amber-500','danger'=>'bg-red-500','success'=>'bg-brand-500'][$note->data['type'] ?? 'info']); ?>"></span>
                            <div class="min-w-0">
                                <div class="text-sm font-semibold text-slate-700"><?php echo e($note->data['title'] ?? ''); ?></div>
                                <div class="text-xs text-slate-500 truncate"><?php echo e($note->data['message'] ?? ''); ?></div>
                                <div class="text-[10px] text-slate-400 mt-1"><?php echo e($note->created_at->diffForHumans()); ?></div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="px-4 py-8 text-center text-sm text-slate-400">لا توجد إشعارات جديدة</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div x-data="{ open: false }" class="relative">
            <button @click="open = !open" class="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100">
                <div class="w-9 h-9 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold">
                    <?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?>

                </div>
                <div class="hidden sm:block text-right leading-tight">
                    <div class="text-sm font-semibold text-slate-700"><?php echo e(auth()->user()->name); ?></div>
                    <div class="text-[11px] text-slate-400"><?php echo e(auth()->user()->role_label); ?></div>
                </div>
            </button>
        </div>
    </div>
</header>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/partials/topbar.blade.php ENDPATH**/ ?>