<?php $__env->startSection('title', 'الأصناف'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-4">
    <h2 class="text-lg font-bold text-slate-700">قائمة الأصناف</h2>
    <a href="<?php echo e(route('items.create')); ?>" class="bg-brand-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> صنف جديد
    </a>
</div>

<div class="card p-5">
    <form method="GET" class="flex flex-wrap gap-3 mb-4">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="بحث باسم الصنف"
               class="flex-1 min-w-48 px-3 py-2 rounded-xl border border-slate-200 outline-none focus:border-brand-500">
        <select name="category" class="px-3 py-2 rounded-xl border border-slate-200">
            <option value="">كل التصنيفات</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>" <?php if(request('category') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="status" class="px-3 py-2 rounded-xl border border-slate-200">
            <option value="">الكل</option>
            <option value="available" <?php if(request('status')==='available'): echo 'selected'; endif; ?>>متاح</option>
            <option value="unavailable" <?php if(request('status')==='unavailable'): echo 'selected'; endif; ?>>غير متاح</option>
        </select>
        <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">تصفية</button>
    </form>

    <div class="overflow-x-auto scrollbar-thin">
        <table class="w-full text-sm">
            <thead class="text-slate-400 text-right border-b">
                <tr>
                    <th class="py-2 font-medium">الصنف</th>
                    <th class="py-2 font-medium">التصنيف</th>
                    <th class="py-2 font-medium">السعر</th>
                    <th class="py-2 font-medium">التكلفة</th>
                    <th class="py-2 font-medium">الربح</th>
                    <th class="py-2 font-medium">الهامش</th>
                    <th class="py-2 font-medium">الحالة</th>
                    <th class="py-2 font-medium"></th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50">
                        <td class="py-3">
                            <div class="flex items-center gap-3">
                                <img src="<?php echo e($item->image_url); ?>" class="w-10 h-10 rounded-lg object-cover">
                                <span class="font-semibold text-slate-700"><?php echo e($item->name); ?></span>
                            </div>
                        </td>
                        <td class="py-3 text-slate-500"><?php echo e($item->category?->name); ?></td>
                        <td class="py-3 font-semibold"><?php echo e(money($item->price)); ?></td>
                        <td class="py-3 text-slate-500"><?php echo e(money($item->cost)); ?></td>
                        <td class="py-3 text-violet-600"><?php echo e(money($item->profit)); ?></td>
                        <td class="py-3">
                            <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?php echo e($item->margin >= 50 ? 'bg-brand-100 text-brand-700' : ($item->margin >= 25 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700')); ?>">
                                <?php echo e($item->margin); ?>٪
                            </span>
                        </td>
                        <td class="py-3">
                            <span class="px-2 py-0.5 rounded-full text-xs <?php echo e($item->is_available ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-slate-500'); ?>">
                                <?php echo e($item->is_available ? 'متاح' : 'معطّل'); ?>

                            </span>
                        </td>
                        <td class="py-3">
                            <div class="flex gap-1">
                                <a href="<?php echo e(route('items.edit', $item)); ?>" class="p-2 text-slate-400 hover:text-brand-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'edit','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></a>
                                <form method="POST" action="<?php echo e(route('items.destroy', $item)); ?>" onsubmit="return confirm('حذف الصنف؟')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="p-2 text-slate-400 hover:text-red-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8" class="py-10 text-center text-slate-400">لا توجد أصناف</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($items->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/menu/items/index.blade.php ENDPATH**/ ?>