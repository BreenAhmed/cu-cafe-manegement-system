<?php
    $nav = [
        ['route' => 'dashboard', 'label' => 'لوحة التحكم', 'icon' => 'dashboard', 'can' => 'access dashboard'],
        ['route' => 'pos.index', 'label' => 'نقطة البيع', 'icon' => 'pos', 'can' => 'use pos'],
        ['route' => 'kitchen.index', 'label' => 'شاشة المطبخ', 'icon' => 'kitchen', 'can' => 'view kitchen'],
        ['route' => 'orders.index', 'label' => 'الطلبات', 'icon' => 'list', 'can' => null],
        ['route' => 'tables.index', 'label' => 'الطاولات', 'icon' => 'pos', 'can' => 'use pos'],
        ['route' => 'shifts.index', 'label' => 'الورديات', 'icon' => 'clock', 'can' => 'manage shifts'],
        ['route' => 'items.index', 'label' => 'الأصناف', 'icon' => 'menu', 'can' => 'manage menu'],
        ['route' => 'categories.index', 'label' => 'التصنيفات', 'icon' => 'menu', 'can' => 'manage menu'],
        ['route' => 'inventory.ingredients.index', 'label' => 'المكوّنات', 'icon' => 'box', 'can' => 'manage inventory'],
        ['route' => 'inventory.stock.index', 'label' => 'حركة المخزون', 'icon' => 'box', 'can' => 'manage inventory'],
        ['route' => 'inventory.units.index', 'label' => 'وحدات القياس', 'icon' => 'list', 'can' => 'manage inventory'],
        ['route' => 'inventory.suppliers.index', 'label' => 'الموردون', 'icon' => 'truck', 'can' => 'manage suppliers'],
        ['route' => 'inventory.purchases.index', 'label' => 'المشتريات', 'icon' => 'truck', 'can' => 'manage purchases'],
        ['route' => 'accounting.index', 'label' => 'المحاسبة', 'icon' => 'money', 'can' => 'manage accounting'],
        ['route' => 'accounting.expenses.index', 'label' => 'المصروفات', 'icon' => 'money', 'can' => 'manage expenses'],
        ['route' => 'reports.index', 'label' => 'التقارير', 'icon' => 'chart', 'can' => 'view reports'],
        ['route' => 'admin.users.index', 'label' => 'المستخدمون', 'icon' => 'users', 'can' => 'manage users'],
        ['route' => 'admin.roles.index', 'label' => 'الأدوار والصلاحيات', 'icon' => 'shield', 'can' => 'manage roles'],
        ['route' => 'admin.activity.index', 'label' => 'سجل التدقيق', 'icon' => 'shield', 'can' => 'view audit logs'],
        ['route' => 'admin.settings.index', 'label' => 'الإعدادات', 'icon' => 'cog', 'can' => 'manage settings'],
    ];
?>

<aside x-cloak
       :class="sidebarOpen ? 'translate-x-0' : 'translate-x-full'"
       class="fixed lg:static lg:translate-x-0 inset-y-0 right-0 z-40 w-72 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200">
    <div class="h-16 flex items-center gap-3 px-6 border-b border-white/10">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-melon-500 flex items-center justify-center font-extrabold text-white text-lg">CU</div>
        <div>
            <div class="text-white font-bold leading-tight"><?php echo e(\App\Models\Setting::get('brand_name', 'CU')); ?></div>
            <div class="text-[11px] text-slate-400">كافيه البطيخ</div>
        </div>
    </div>

    <nav class="flex-1 overflow-y-auto scrollbar-thin py-4 px-3 space-y-1">
        <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(! $link['can'] || auth()->user()->can($link['can'])): ?>
                <?php $active = request()->routeIs($link['route']) || request()->routeIs(\Illuminate\Support\Str::beforeLast($link['route'], '.').'.*') && \Illuminate\Support\Str::contains(request()->route()->getName() ?? '', \Illuminate\Support\Str::beforeLast($link['route'], '.')); ?>
                <a href="<?php echo e(route($link['route'])); ?>"
                   class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition
                          <?php echo e(request()->routeIs($link['route']) ? 'bg-brand-600 text-white shadow' : 'hover:bg-white/5 hover:text-white'); ?>">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $link['icon'],'class' => 'w-5 h-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($link['icon']),'class' => 'w-5 h-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <span><?php echo e($link['label']); ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <form method="POST" action="<?php echo e(route('logout')); ?>" class="p-3 border-t border-white/10">
        <?php echo csrf_field(); ?>
        <button type="submit" class="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-red-300 hover:bg-red-500/10 transition">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <span>تسجيل الخروج</span>
        </button>
    </form>
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>