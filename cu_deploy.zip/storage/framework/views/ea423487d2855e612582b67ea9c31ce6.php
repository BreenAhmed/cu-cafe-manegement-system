<?php $__env->startSection('title', 'سجل التدقيق'); ?>

<?php $__env->startSection('content'); ?>
<form method="GET" class="card p-4 mb-4 flex gap-3">
    <select name="log" class="px-3 py-2 rounded-xl border border-slate-200">
        <option value="">كل السجلات</option>
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($log); ?>" <?php if(request('log')===$log): echo 'selected'; endif; ?>><?php echo e($log); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">تصفية</button>
</form>

<div class="card p-5 overflow-x-auto scrollbar-thin">
    <table class="w-full text-sm">
        <thead class="text-slate-400 text-right border-b"><tr><th class="py-2">الحدث</th><th class="py-2">الوصف</th><th class="py-2">المستخدم</th><th class="py-2">السجل</th><th class="py-2">التاريخ</th></tr></thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3"><span class="px-2 py-0.5 rounded-full text-xs bg-slate-100"><?php echo e(['created'=>'إنشاء','updated'=>'تعديل','deleted'=>'حذف'][$a->event] ?? $a->event); ?></span></td>
                    <td class="py-3 text-slate-600"><?php echo e($a->description); ?></td>
                    <td class="py-3 text-slate-500"><?php echo e($a->causer?->name ?? 'النظام'); ?></td>
                    <td class="py-3 text-slate-400"><?php echo e($a->log_name); ?></td>
                    <td class="py-3 text-slate-400"><?php echo e($a->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="py-10 text-center text-slate-400">لا توجد سجلات</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($activities->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/admin/activity/index.blade.php ENDPATH**/ ?>