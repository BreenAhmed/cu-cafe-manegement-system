<?php $__env->startSection('title', 'التقارير والتحليلات'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <form method="GET" class="card p-4 flex flex-wrap gap-3 items-end">
        <div><label class="block text-xs text-slate-500 mb-1">من</label><input type="date" name="from" value="<?php echo e($from->toDateString()); ?>" class="px-3 py-2 rounded-xl border border-slate-200"></div>
        <div><label class="block text-xs text-slate-500 mb-1">إلى</label><input type="date" name="to" value="<?php echo e($to->toDateString()); ?>" class="px-3 py-2 rounded-xl border border-slate-200"></div>
        <button class="bg-brand-600 text-white px-5 py-2 rounded-xl font-semibold">عرض</button>
        <div class="ms-auto flex gap-2">
            <a href="<?php echo e(route('reports.sales', request()->query())); ?>" class="px-4 py-2 bg-slate-100 rounded-xl text-sm">المبيعات</a>
            <a href="<?php echo e(route('reports.profit', request()->query())); ?>" class="px-4 py-2 bg-slate-100 rounded-xl text-sm">الأرباح</a>
            <a href="<?php echo e(route('reports.inventory', request()->query())); ?>" class="px-4 py-2 bg-slate-100 rounded-xl text-sm">المخزون</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export reports')): ?>
                <a href="<?php echo e(route('reports.export', ['type' => 'summary'] + request()->query())); ?>" class="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-semibold">تصدير PDF</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'المبيعات (صافي)','value' => money($sales['net']),'icon' => 'money','color' => 'brand','sub' => $sales['orders'].' طلب']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'المبيعات (صافي)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(money($sales['net'])),'icon' => 'money','color' => 'brand','sub' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sales['orders'].' طلب')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'الأرباح','value' => money($sales['profit']),'icon' => 'chart','color' => 'violet']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'الأرباح','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(money($sales['profit'])),'icon' => 'chart','color' => 'violet']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'المصروفات','value' => money($expenses),'icon' => 'money','color' => 'melon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'المصروفات','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(money($expenses)),'icon' => 'money','color' => 'melon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'متوسط زمن التحضير','value' => $prep['avg_prep_minutes'].' دقيقة','icon' => 'clock','color' => 'amber']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'متوسط زمن التحضير','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($prep['avg_prep_minutes'].' دقيقة'),'icon' => 'clock','color' => 'amber']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
    </div>

    <div class="card p-6">
        <h3 class="font-bold text-slate-700 mb-4">منحنى المبيعات والأرباح</h3>
        <canvas id="repChart" height="90"></canvas>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="card p-6">
            <h3 class="font-bold text-slate-700 mb-4">الأكثر مبيعاً</h3>
            <table class="w-full text-sm">
                <thead class="text-slate-400 text-right border-b"><tr><th class="py-2">الصنف</th><th class="py-2">الكمية</th><th class="py-2">الإيراد</th></tr></thead>
                <tbody class="divide-y">
                    <?php $__empty_1 = true; $__currentLoopData = $bestSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr><td class="py-2 font-semibold"><?php echo e($b['name']); ?></td><td class="py-2"><?php echo e((int)$b['qty']); ?></td><td class="py-2"><?php echo e(money($b['revenue'])); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="3" class="py-6 text-center text-slate-400">لا بيانات</td></tr> <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card p-6">
            <h3 class="font-bold text-slate-700 mb-4">المبيعات حسب الكاشير</h3>
            <table class="w-full text-sm">
                <thead class="text-slate-400 text-right border-b"><tr><th class="py-2">الكاشير</th><th class="py-2">الطلبات</th><th class="py-2">المبيعات</th></tr></thead>
                <tbody class="divide-y">
                    <?php $__empty_1 = true; $__currentLoopData = $byCashier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr><td class="py-2 font-semibold"><?php echo e($c['cashier']); ?></td><td class="py-2"><?php echo e((int)$c['orders']); ?></td><td class="py-2"><?php echo e(money($c['net'])); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="3" class="py-6 text-center text-slate-400">لا بيانات</td></tr> <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    new Chart(document.getElementById('repChart'), {
        type: 'line',
        data: { labels: <?php echo json_encode($series['labels'], 15, 512) ?>, datasets: [
            { label: 'المبيعات', data: <?php echo json_encode($series['net'], 15, 512) ?>, borderColor: '#16a34a', backgroundColor: 'rgba(22,163,74,.1)', fill: true, tension: .35 },
            { label: 'الأرباح', data: <?php echo json_encode($series['profit'], 15, 512) ?>, borderColor: '#7c3aed', fill: false, tension: .35 },
        ] },
        options: { plugins: { legend: { labels: { font: { family: 'Cairo' } } } }, scales: { x: { ticks: { font: { family: 'Cairo' } } }, y: { ticks: { font: { family: 'Cairo' } } } } }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/reports/index.blade.php ENDPATH**/ ?>