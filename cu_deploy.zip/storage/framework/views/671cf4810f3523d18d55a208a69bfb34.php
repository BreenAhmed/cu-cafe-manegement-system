<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $map = [
        'new' => ['جديد', 'bg-blue-100 text-blue-700'],
        'preparing' => ['قيد التحضير', 'bg-amber-100 text-amber-700'],
        'ready' => ['جاهز', 'bg-brand-100 text-brand-700'],
        'delivered' => ['تم التسليم', 'bg-slate-100 text-slate-600'],
        'cancelled' => ['ملغي', 'bg-red-100 text-red-700'],
    ];
    [$label, $classes] = $map[$status] ?? [$status, 'bg-slate-100 text-slate-600'];
?>

<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold <?php echo e($classes); ?>"><?php echo e($label); ?></span>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/components/order-status.blade.php ENDPATH**/ ?>