<?php $__env->startSection('title', $item->exists ? 'تعديل صنف' : 'صنف جديد'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $ingredientsData = $ingredients->map(fn ($i) => ['id' => $i->id, 'name' => $i->name, 'unit' => $i->unit?->abbreviation, 'cost' => (float) $i->cost_per_unit]);
    $existingRecipe = $item->recipeItems->map(fn ($r) => ['ingredient_id' => $r->ingredient_id, 'quantity' => (float) $r->quantity]);
?>

<form method="POST" action="<?php echo e($item->exists ? route('items.update', $item) : route('items.store')); ?>" enctype="multipart/form-data"
      x-data="recipeBuilder({ ingredients: <?php echo e(Illuminate\Support\Js::from($ingredientsData)); ?>, recipe: <?php echo e(Illuminate\Support\Js::from($existingRecipe->isEmpty() ? [['ingredient_id' => '', 'quantity' => '']] : $existingRecipe)); ?> })"
      class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <?php echo csrf_field(); ?>
    <?php if($item->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="lg:col-span-2 space-y-6">
        <div class="card p-6 space-y-4">
            <h3 class="font-bold text-slate-700">بيانات الصنف</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">الاسم</label>
                    <input name="name" value="<?php echo e(old('name', $item->name)); ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200 outline-none focus:border-brand-500">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">التصنيف</label>
                    <select name="category_id" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php if(old('category_id', $item->category_id) == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">سعر البيع</label>
                    <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $item->price)); ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">تكلفة يدوية (اختياري)</label>
                    <input type="number" step="0.01" name="manual_cost" value="<?php echo e(old('manual_cost', $item->manual_cost)); ?>" placeholder="تُحسب من الوصفة إن تُركت فارغة" class="w-full px-3 py-2 rounded-xl border border-slate-200">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">رمز SKU</label>
                    <input name="sku" value="<?php echo e(old('sku', $item->sku)); ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-600 mb-1">وقت التحضير (دقيقة)</label>
                    <input type="number" name="prep_time_minutes" value="<?php echo e(old('prep_time_minutes', $item->prep_time_minutes)); ?>" required class="w-full px-3 py-2 rounded-xl border border-slate-200">
                </div>
            </div>
            <div>
                <label class="block text-sm font-semibold text-slate-600 mb-1">الوصف</label>
                <textarea name="description" rows="2" class="w-full px-3 py-2 rounded-xl border border-slate-200"><?php echo e(old('description', $item->description)); ?></textarea>
            </div>
            <div class="flex flex-wrap gap-6">
                <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_available" value="1" <?php if(old('is_available', $item->is_available)): echo 'checked'; endif; ?> class="rounded text-brand-600"> متاح للبيع</label>
                <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="track_inventory" value="1" <?php if(old('track_inventory', $item->track_inventory)): echo 'checked'; endif; ?> class="rounded text-brand-600"> خصم المكوّنات من المخزون</label>
            </div>
        </div>

        
        <div class="card p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="font-bold text-slate-700">الوصفة (المكوّنات)</h3>
                <button type="button" @click="addRow()" class="text-brand-600 text-sm font-semibold flex items-center gap-1"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> إضافة مكوّن</button>
            </div>
            <div class="space-y-2">
                <template x-for="(row, idx) in recipe" :key="idx">
                    <div class="flex gap-2 items-center">
                        <select :name="`recipe[${idx}][ingredient_id]`" x-model.number="row.ingredient_id" class="flex-1 px-3 py-2 rounded-xl border border-slate-200">
                            <option value="">— اختر مكوّناً —</option>
                            <template x-for="ing in ingredients" :key="ing.id">
                                <option :value="ing.id" x-text="`${ing.name} (${ing.unit})`"></option>
                            </template>
                        </select>
                        <input type="number" step="0.001" :name="`recipe[${idx}][quantity]`" x-model.number="row.quantity" placeholder="الكمية" class="w-28 px-3 py-2 rounded-xl border border-slate-200">
                        <button type="button" @click="removeRow(idx)" class="p-2 text-red-400 hover:text-red-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                    </div>
                </template>
            </div>
            <div class="mt-4 flex justify-between text-sm border-t pt-3">
                <span class="text-slate-500">تكلفة الوصفة المقدّرة</span>
                <span class="font-bold text-slate-700" x-text="recipeCostLabel"></span>
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <div class="card p-6">
            <h3 class="font-bold text-slate-700 mb-3">صورة الصنف</h3>
            <img src="<?php echo e($item->image_url); ?>" class="w-full aspect-square object-cover rounded-xl mb-3">
            <input type="file" name="image" accept="image/*" class="w-full text-sm">
        </div>
        <button class="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-xl"><?php echo e($item->exists ? 'حفظ التعديلات' : 'إضافة الصنف'); ?></button>
        <a href="<?php echo e(route('items.index')); ?>" class="block text-center text-slate-500 text-sm">رجوع للقائمة</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function recipeBuilder(config) {
    return {
        ingredients: config.ingredients,
        recipe: config.recipe.length ? config.recipe : [{ ingredient_id: '', quantity: '' }],
        addRow() { this.recipe.push({ ingredient_id: '', quantity: '' }); },
        removeRow(i) { this.recipe.splice(i, 1); if (!this.recipe.length) this.addRow(); },
        get recipeCost() {
            return this.recipe.reduce((sum, r) => {
                const ing = this.ingredients.find(i => i.id === r.ingredient_id);
                return sum + (ing ? ing.cost * (r.quantity || 0) : 0);
            }, 0);
        },
        get recipeCostLabel() { return this.recipeCost.toFixed(2) + ' <?php echo e(\App\Models\Setting::get('currency', 'ل.س')); ?>'; },
    };
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/menu/items/form.blade.php ENDPATH**/ ?>