<?php $__env->startSection('title', 'تفاصيل الطلب #' . $order->order_number); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2 card p-6">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-bold">الأصناف</h2>
            <?php if (isset($component)) { $__componentOriginal2dcd595ef873cce5a53e09953a1030a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dcd595ef873cce5a53e09953a1030a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.order-status','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dcd595ef873cce5a53e09953a1030a0)): ?>
<?php $attributes = $__attributesOriginal2dcd595ef873cce5a53e09953a1030a0; ?>
<?php unset($__attributesOriginal2dcd595ef873cce5a53e09953a1030a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dcd595ef873cce5a53e09953a1030a0)): ?>
<?php $component = $__componentOriginal2dcd595ef873cce5a53e09953a1030a0; ?>
<?php unset($__componentOriginal2dcd595ef873cce5a53e09953a1030a0); ?>
<?php endif; ?>
        </div>
        <table class="w-full text-sm">
            <thead class="text-slate-400 text-right border-b">
                <tr><th class="py-2">الصنف</th><th class="py-2">السعر</th><th class="py-2">الكمية</th><th class="py-2">الخصم</th><th class="py-2">الصافي</th></tr>
            </thead>
            <tbody class="divide-y">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-3 font-semibold text-slate-700"><?php echo e($item->name); ?>

                            <?php if($item->notes): ?><span class="block text-xs text-amber-600"><?php echo e($item->notes); ?></span><?php endif; ?>
                        </td>
                        <td class="py-3"><?php echo e(money($item->unit_price)); ?></td>
                        <td class="py-3"><?php echo e($item->quantity); ?></td>
                        <td class="py-3 text-melon-600"><?php echo e($item->discount_amount > 0 ? '- '.money($item->discount_amount) : '—'); ?></td>
                        <td class="py-3 font-bold"><?php echo e(money($item->net_total)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="mt-6 flex flex-wrap gap-2">
            <a href="<?php echo e(route('orders.invoice', $order)); ?>" target="_blank" class="bg-brand-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'printer','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'printer','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> الفاتورة</a>
            <?php if($order->status !== 'cancelled' && auth()->user()->canAny(['use pos', 'manage accounting'])): ?>
                <form method="POST" action="<?php echo e(route('orders.cancel', $order)); ?>" onsubmit="return confirm('هل تريد إلغاء هذا الطلب؟ سيتم عكس آثاره على المخزون والحسابات.')">
                    <?php echo csrf_field(); ?>
                    <button class="bg-red-50 text-red-600 px-4 py-2 rounded-xl font-semibold">إلغاء الطلب</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="space-y-4">
        <div class="card p-6 space-y-2 text-sm">
            <div class="flex justify-between"><span class="text-slate-500">رقم الفاتورة</span><span class="font-semibold"><?php echo e($order->invoice_number); ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">الكاشير</span><span><?php echo e($order->user?->name); ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">النوع</span><span><?php echo e($order->type_label); ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">طريقة الدفع</span><span><?php echo e($order->payment_method_label); ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">التاريخ</span><span><?php echo e($order->created_at->format('Y-m-d H:i')); ?></span></div>
            <?php if($order->prep_duration !== null): ?>
                <div class="flex justify-between"><span class="text-slate-500">زمن التحضير</span><span><?php echo e($order->prep_duration); ?> دقيقة</span></div>
            <?php endif; ?>
        </div>

        <div class="card p-6 space-y-2 text-sm">
            <div class="flex justify-between"><span class="text-slate-500">المجموع</span><span><?php echo e(money($order->subtotal)); ?></span></div>
            <div class="flex justify-between text-melon-600"><span>الخصم</span><span>- <?php echo e(money($order->discount_total)); ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">التكلفة</span><span><?php echo e(money($order->cost_total)); ?></span></div>
            <div class="flex justify-between text-violet-600"><span>الربح</span><span><?php echo e(money($order->profit)); ?></span></div>
            <div class="flex justify-between text-lg font-extrabold pt-2 border-t"><span>الإجمالي</span><span><?php echo e(money($order->total)); ?></span></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/orders/show.blade.php ENDPATH**/ ?>