<?php $__env->startSection('title', 'الطاولات'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ open: false, form: { id: null, name: '', capacity: 4, sort_order: 0, is_active: true } }">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-slate-700">إدارة الطاولات</h2>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage menu')): ?>
            <button @click="form = { id: null, name: '', capacity: 4, sort_order: 0, is_active: true }; open = true"
                    class="bg-brand-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> طاولة جديدة
            </button>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mb-6">
        <?php $__empty_1 = true; $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card p-4 flex flex-col gap-3 <?php echo e($table->isOccupied() ? 'border-r-4 border-melon-400' : 'border-r-4 border-brand-200'); ?>">
                <div class="flex items-start justify-between">
                    <div>
                        <div class="font-bold text-slate-700"><?php echo e($table->name); ?></div>
                        <div class="text-xs text-slate-400"><?php echo e($table->capacity); ?> مقاعد</div>
                    </div>
                    <span class="px-2 py-0.5 rounded-full text-xs font-semibold
                                 <?php echo e($table->isOccupied() ? 'bg-melon-100 text-melon-700' : 'bg-brand-100 text-brand-700'); ?>">
                        <?php echo e($table->status_label); ?>

                    </span>
                </div>

                <?php if($table->isOccupied()): ?>
                    <div class="text-sm space-y-1">
                        <div class="flex justify-between text-slate-500">
                            <span>الطلبات</span>
                            <span class="font-bold"><?php echo e($table->activeOrders->count()); ?></span>
                        </div>
                        <div class="flex justify-between text-melon-600">
                            <span>الإجمالي</span>
                            <span class="font-bold"><?php echo e(money($table->running_total)); ?></span>
                        </div>
                    </div>

                    <div class="space-y-1 max-h-24 overflow-y-auto scrollbar-thin">
                        <?php $__currentLoopData = $table->activeOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-xs bg-slate-50 rounded-lg px-2 py-1.5 flex justify-between">
                                <span class="text-slate-600">#<?php echo e($ord->order_number); ?> <?php if (isset($component)) { $__componentOriginal2dcd595ef873cce5a53e09953a1030a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dcd595ef873cce5a53e09953a1030a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.order-status','data' => ['status' => $ord->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ord->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dcd595ef873cce5a53e09953a1030a0)): ?>
<?php $attributes = $__attributesOriginal2dcd595ef873cce5a53e09953a1030a0; ?>
<?php unset($__attributesOriginal2dcd595ef873cce5a53e09953a1030a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dcd595ef873cce5a53e09953a1030a0)): ?>
<?php $component = $__componentOriginal2dcd595ef873cce5a53e09953a1030a0; ?>
<?php unset($__componentOriginal2dcd595ef873cce5a53e09953a1030a0); ?>
<?php endif; ?></span>
                                <span class="font-bold"><?php echo e(money($ord->total)); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div x-data="{ payMethod: 'cash' }" class="flex flex-col gap-1.5">
                        <select x-model="payMethod" class="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-xs">
                            <option value="cash">نقدي</option>
                            <option value="card">بطاقة</option>
                            <option value="transfer">تحويل</option>
                        </select>
                        <form method="POST" action="<?php echo e(route('tables.settle', $table)); ?>" onsubmit="return confirm('تسوية حساب <?php echo e($table->name); ?>؟')">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="payment_method" :value="payMethod">
                            <button class="w-full bg-brand-600 text-white text-xs font-bold py-1.5 rounded-lg">تسوية الحساب ✓</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('tables.clear', $table)); ?>" onsubmit="return confirm('إلغاء جميع طلبات <?php echo e($table->name); ?>؟')">
                            <?php echo csrf_field(); ?>
                            <button class="w-full bg-red-50 text-red-600 text-xs font-semibold py-1.5 rounded-lg">إلغاء الطلبات</button>
                        </form>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('pos.index')); ?>" class="block text-center text-xs text-brand-600 bg-brand-50 py-2 rounded-lg font-semibold">
                        + فتح طلب جديد
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage menu')): ?>
                    <div class="flex gap-1 border-t pt-2">
                        <button @click='form = <?php echo e(Illuminate\Support\Js::from(["id"=>$table->id,"name"=>$table->name,"capacity"=>$table->capacity,"sort_order"=>$table->sort_order,"is_active"=>(bool)$table->is_active])); ?>; open = true'
                                class="flex-1 p-1.5 text-slate-400 hover:text-brand-600 flex justify-center">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'edit','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit','class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </button>
                        <form method="POST" action="<?php echo e(route('tables.destroy', $table)); ?>" onsubmit="return confirm('حذف الطاولة؟')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="flex-1 p-1.5 text-slate-400 hover:text-red-600"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full card p-10 text-center text-slate-400">
                لا توجد طاولات بعد.
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage menu')): ?>
                    <button @click="open = true" class="block mx-auto mt-3 text-brand-600 font-semibold text-sm underline">أضف أول طاولة</button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage menu')): ?>
        <div x-show="open" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" @click.self="open = false">
            <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
                <h3 class="font-bold text-lg mb-4" x-text="form.id ? 'تعديل طاولة' : 'طاولة جديدة'"></h3>
                <form :action="form.id ? '<?php echo e(url('tables')); ?>/' + form.id : '<?php echo e(route('tables.store')); ?>'" method="POST" class="space-y-3">
                    <?php echo csrf_field(); ?>
                    <template x-if="form.id"><input type="hidden" name="_method" value="PUT"></template>
                    <div>
                        <label class="block text-sm font-semibold text-slate-600 mb-1">الاسم</label>
                        <input name="name" x-model="form.name" required placeholder="طاولة 1"
                               class="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-brand-500 outline-none">
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-sm font-semibold text-slate-600 mb-1">عدد المقاعد</label>
                            <input type="number" name="capacity" x-model.number="form.capacity" min="1" max="100"
                                   class="w-full px-3 py-2 rounded-xl border border-slate-200">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-slate-600 mb-1">الترتيب</label>
                            <input type="number" name="sort_order" x-model.number="form.sort_order" min="0"
                                   class="w-full px-3 py-2 rounded-xl border border-slate-200">
                        </div>
                    </div>
                    <label class="flex items-center gap-2 text-sm">
                        <input type="checkbox" name="is_active" value="1" x-model="form.is_active" class="rounded text-brand-600">
                        نشطة
                    </label>
                    <div class="flex gap-2 pt-2">
                        <button class="flex-1 bg-brand-600 text-white py-2.5 rounded-xl font-bold">حفظ</button>
                        <button type="button" @click="open = false" class="px-4 bg-slate-100 rounded-xl">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cu/resources/views/tables/index.blade.php ENDPATH**/ ?>